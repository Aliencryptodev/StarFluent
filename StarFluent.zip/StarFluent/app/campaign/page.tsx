
import RaceSelector from './RaceSelector';

export default function CampaignPage() {
  return <RaceSelector />;
}